# Adding language files
1. Copy the English language files from 
```
./attacks/Handshake Snooper/language/en.sh
./attacks/Captive Portal/language/en.sh
./language/en.sh
```
2. Translate
3. Save them as `LANGUAGE_CODE.sh` to respective locations.
Resource: [LANGUAGE_CODE](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes) (ISO 639-1)
